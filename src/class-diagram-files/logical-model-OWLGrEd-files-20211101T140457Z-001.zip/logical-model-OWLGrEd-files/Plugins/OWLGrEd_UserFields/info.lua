{
  id = "OWLGrEd_UserFields",
  name = "OWLGrEd_UserFields",
  version = "0.10",
}